package com.tomekl007.payment.details.api;

public interface PaymentDetails {
  String getInfoAboutPayment(String cityName);
}
