package com.tomekl007.chapter_1.beans;

public interface ExternalService {
  void call();
}
