package com.tomekl007.chapter_2.profilesconfig;

public interface DataSourceConfig {
    public void setup();
}