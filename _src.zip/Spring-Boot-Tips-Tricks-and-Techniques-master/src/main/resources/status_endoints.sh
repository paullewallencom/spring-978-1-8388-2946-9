http://localhost:8080/application/info
http://localhost:8080/application/health


http://localhost:8080/application
http://localhost:8080/application/metrics